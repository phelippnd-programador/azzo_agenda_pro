import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { InvoiceForm } from '@/components/fiscal/InvoiceForm';
import { InvoiceList } from '@/components/fiscal/InvoiceList';
import { InvoiceViewer } from '@/components/fiscal/InvoiceViewer';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Invoice, InvoiceFormData } from '@/types/invoice';
import { invoiceStorage } from '@/lib/invoice-storage';
import { toast } from 'sonner';
import { FileText, List } from 'lucide-react';

export default function InvoiceEmission() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [invoiceToCancel, setInvoiceToCancel] = useState<Invoice | null>(null);
  const [activeTab, setActiveTab] = useState('new');

  useEffect(() => {
    loadInvoices();
  }, []);

  const loadInvoices = () => {
    const allInvoices = invoiceStorage.getAll();
    setInvoices(allInvoices.sort((a, b) => 
      new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime()
    ));
  };

  const handleSubmit = (formData: InvoiceFormData, isDraft: boolean) => {
    try {
      const status = isDraft ? 'DRAFT' : 'ISSUED';
      const invoice = invoiceStorage.createInvoice(formData, status);
      
      loadInvoices();
      
      if (isDraft) {
        toast.success('Rascunho salvo com sucesso!');
      } else {
        toast.success(`Nota fiscal ${invoice.number} emitida com sucesso!`, {
          description: 'A nota foi registrada e está disponível para impressão.',
        });
        setSelectedInvoice(invoice);
        setIsViewerOpen(true);
      }
      
      setActiveTab('list');
    } catch (error) {
      toast.error('Erro ao processar nota fiscal');
      console.error(error);
    }
  };

  const handleView = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setIsViewerOpen(true);
  };

  const handlePrint = (invoice: Invoice) => {
    // Mock print functionality
    toast.info('Função de impressão será implementada em breve', {
      description: 'Por enquanto, você pode visualizar os detalhes da nota.',
    });
    handleView(invoice);
  };

  const handleCancelRequest = (invoice: Invoice) => {
    setInvoiceToCancel(invoice);
  };

  const handleCancelConfirm = () => {
    if (!invoiceToCancel) return;

    try {
      const updatedInvoice = { ...invoiceToCancel, status: 'CANCELLED' as const };
      invoiceStorage.save(updatedInvoice);
      loadInvoices();
      toast.success(`Nota fiscal ${invoiceToCancel.number} cancelada com sucesso`);
      setInvoiceToCancel(null);
    } catch (error) {
      toast.error('Erro ao cancelar nota fiscal');
      console.error(error);
    }
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Emissão de Notas Fiscais</h1>
          <p className="text-muted-foreground mt-2">
            Emita NF-e e NFC-e para seus serviços prestados
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="new" className="gap-2">
              <FileText className="w-4 h-4" />
              Nova Nota
            </TabsTrigger>
            <TabsTrigger value="list" className="gap-2">
              <List className="w-4 h-4" />
              Histórico ({invoices.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="new" className="mt-6">
            <InvoiceForm onSubmit={handleSubmit} />
          </TabsContent>

          <TabsContent value="list" className="mt-6">
            <InvoiceList
              invoices={invoices}
              onView={handleView}
              onPrint={handlePrint}
              onCancel={handleCancelRequest}
            />
          </TabsContent>
        </Tabs>

        {/* Invoice Viewer Dialog */}
        <Dialog open={isViewerOpen} onOpenChange={setIsViewerOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Detalhes da Nota Fiscal</DialogTitle>
              <DialogDescription>
                Visualização completa da nota fiscal emitida
              </DialogDescription>
            </DialogHeader>
            {selectedInvoice && <InvoiceViewer invoice={selectedInvoice} />}
          </DialogContent>
        </Dialog>

        {/* Cancel Confirmation Dialog */}
        <AlertDialog open={!!invoiceToCancel} onOpenChange={() => setInvoiceToCancel(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Cancelar Nota Fiscal?</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja cancelar a nota fiscal {invoiceToCancel?.number}?
                Esta ação não pode ser desfeita.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Não, manter nota</AlertDialogCancel>
              <AlertDialogAction onClick={handleCancelConfirm} className="bg-red-600 hover:bg-red-700">
                Sim, cancelar nota
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </MainLayout>
  );
}