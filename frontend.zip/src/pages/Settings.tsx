import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import {
  Building2,
  User,
  Bell,
  Clock,
  Palette,
  Shield,
  Save,
  Upload,
} from 'lucide-react';

export default function Settings() {
  const { user } = useAuth();
  const [isSaving, setIsSaving] = useState(false);
  
  // Salon settings
  const [salonName, setSalonName] = useState(user?.salonName || 'Bella Studio');
  const [salonPhone, setSalonPhone] = useState(user?.phone || '(11) 99999-0000');
  const [salonEmail, setSalonEmail] = useState(user?.email || 'contato@bellastudio.com');
  const [salonAddress, setSalonAddress] = useState('Rua das Flores, 123 - São Paulo, SP');
  const [salonDescription, setSalonDescription] = useState('Salão de beleza especializado em cortes, coloração e tratamentos capilares.');
  
  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(true);
  const [whatsappNotifications, setWhatsappNotifications] = useState(true);
  const [reminderHours, setReminderHours] = useState('24');
  
  // Business hours
  const [businessHours, setBusinessHours] = useState({
    monday: { open: '09:00', close: '19:00', enabled: true },
    tuesday: { open: '09:00', close: '19:00', enabled: true },
    wednesday: { open: '09:00', close: '19:00', enabled: true },
    thursday: { open: '09:00', close: '19:00', enabled: true },
    friday: { open: '09:00', close: '19:00', enabled: true },
    saturday: { open: '09:00', close: '17:00', enabled: true },
    sunday: { open: '09:00', close: '13:00', enabled: false },
  });

  const dayNames: Record<string, string> = {
    monday: 'Segunda-feira',
    tuesday: 'Terça-feira',
    wednesday: 'Quarta-feira',
    thursday: 'Quinta-feira',
    friday: 'Sexta-feira',
    saturday: 'Sábado',
    sunday: 'Domingo',
  };

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast.success('Configurações salvas com sucesso!');
    setIsSaving(false);
  };

  return (
    <MainLayout title="Configurações" subtitle="Gerencie as configurações do seu salão">
      <Tabs defaultValue="salon" className="space-y-4 sm:space-y-6">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-auto">
          <TabsTrigger value="salon" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2">
            <Building2 className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">Salão</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2">
            <Bell className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">Notificações</span>
          </TabsTrigger>
          <TabsTrigger value="hours" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2">
            <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">Horários</span>
          </TabsTrigger>
          <TabsTrigger value="account" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2">
            <User className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">Conta</span>
          </TabsTrigger>
        </TabsList>

        {/* Salon Settings */}
        <TabsContent value="salon">
          <Card>
            <CardHeader>
              <CardTitle className="text-base sm:text-lg">Informações do Salão</CardTitle>
              <CardDescription className="text-xs sm:text-sm">
                Configure as informações básicas do seu estabelecimento
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 sm:space-y-6">
              {/* Logo */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <Avatar className="w-16 h-16 sm:w-20 sm:h-20">
                  <AvatarImage src="https://mgx-backend-cdn.metadl.com/generate/images/968095/2026-02-12/6c476f2a-8002-4ffb-8394-c90ae976f88c.png" />
                  <AvatarFallback className="text-lg sm:text-xl">BS</AvatarFallback>
                </Avatar>
                <div className="space-y-2">
                  <Button variant="outline" size="sm" className="gap-2 text-xs sm:text-sm">
                    <Upload className="w-3 h-3 sm:w-4 sm:h-4" />
                    Alterar Logo
                  </Button>
                  <p className="text-xs text-gray-500">
                    JPG, PNG ou GIF. Máximo 2MB.
                  </p>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="salonName" className="text-xs sm:text-sm">Nome do Salão</Label>
                  <Input
                    id="salonName"
                    value={salonName}
                    onChange={(e) => setSalonName(e.target.value)}
                    className="text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="salonPhone" className="text-xs sm:text-sm">Telefone</Label>
                  <Input
                    id="salonPhone"
                    value={salonPhone}
                    onChange={(e) => setSalonPhone(e.target.value)}
                    className="text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="salonEmail" className="text-xs sm:text-sm">E-mail</Label>
                  <Input
                    id="salonEmail"
                    type="email"
                    value={salonEmail}
                    onChange={(e) => setSalonEmail(e.target.value)}
                    className="text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="salonAddress" className="text-xs sm:text-sm">Endereço</Label>
                  <Input
                    id="salonAddress"
                    value={salonAddress}
                    onChange={(e) => setSalonAddress(e.target.value)}
                    className="text-sm"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="salonDescription" className="text-xs sm:text-sm">Descrição</Label>
                <Textarea
                  id="salonDescription"
                  value={salonDescription}
                  onChange={(e) => setSalonDescription(e.target.value)}
                  rows={3}
                  className="text-sm"
                />
              </div>

              <Button onClick={handleSave} disabled={isSaving} className="gap-2">
                <Save className="w-4 h-4" />
                {isSaving ? 'Salvando...' : 'Salvar Alterações'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle className="text-base sm:text-lg">Notificações</CardTitle>
              <CardDescription className="text-xs sm:text-sm">
                Configure como você e seus clientes recebem notificações
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 sm:space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 sm:p-4 bg-gray-50 rounded-lg">
                  <div className="space-y-0.5 min-w-0 flex-1 mr-4">
                    <Label className="text-sm font-medium">Notificações por E-mail</Label>
                    <p className="text-xs text-gray-500 truncate">
                      Receba confirmações e lembretes por e-mail
                    </p>
                  </div>
                  <Switch
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>

                <div className="flex items-center justify-between p-3 sm:p-4 bg-gray-50 rounded-lg">
                  <div className="space-y-0.5 min-w-0 flex-1 mr-4">
                    <Label className="text-sm font-medium">Notificações por SMS</Label>
                    <p className="text-xs text-gray-500 truncate">
                      Envie lembretes por SMS para clientes
                    </p>
                  </div>
                  <Switch
                    checked={smsNotifications}
                    onCheckedChange={setSmsNotifications}
                  />
                </div>

                <div className="flex items-center justify-between p-3 sm:p-4 bg-gray-50 rounded-lg">
                  <div className="space-y-0.5 min-w-0 flex-1 mr-4">
                    <Label className="text-sm font-medium">Notificações por WhatsApp</Label>
                    <p className="text-xs text-gray-500 truncate">
                      Envie confirmações e lembretes via WhatsApp
                    </p>
                  </div>
                  <Switch
                    checked={whatsappNotifications}
                    onCheckedChange={setWhatsappNotifications}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reminderHours" className="text-xs sm:text-sm">
                  Lembrete antes do agendamento (horas)
                </Label>
                <Input
                  id="reminderHours"
                  type="number"
                  value={reminderHours}
                  onChange={(e) => setReminderHours(e.target.value)}
                  className="w-full sm:w-32 text-sm"
                />
              </div>

              <Button onClick={handleSave} disabled={isSaving} className="gap-2">
                <Save className="w-4 h-4" />
                {isSaving ? 'Salvando...' : 'Salvar Alterações'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Business Hours */}
        <TabsContent value="hours">
          <Card>
            <CardHeader>
              <CardTitle className="text-base sm:text-lg">Horário de Funcionamento</CardTitle>
              <CardDescription className="text-xs sm:text-sm">
                Defina os horários de funcionamento do seu salão
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(businessHours).map(([day, hours]) => (
                <div
                  key={day}
                  className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 p-3 bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center justify-between sm:justify-start sm:w-40 gap-2">
                    <Switch
                      checked={hours.enabled}
                      onCheckedChange={(checked) =>
                        setBusinessHours((prev) => ({
                          ...prev,
                          [day]: { ...prev[day as keyof typeof prev], enabled: checked },
                        }))
                      }
                    />
                    <span className={`text-sm font-medium ${!hours.enabled && 'text-gray-400'}`}>
                      {dayNames[day]}
                    </span>
                  </div>
                  
                  {hours.enabled && (
                    <div className="flex items-center gap-2 ml-8 sm:ml-0">
                      <Input
                        type="time"
                        value={hours.open}
                        onChange={(e) =>
                          setBusinessHours((prev) => ({
                            ...prev,
                            [day]: { ...prev[day as keyof typeof prev], open: e.target.value },
                          }))
                        }
                        className="w-28 text-sm"
                      />
                      <span className="text-gray-500 text-sm">às</span>
                      <Input
                        type="time"
                        value={hours.close}
                        onChange={(e) =>
                          setBusinessHours((prev) => ({
                            ...prev,
                            [day]: { ...prev[day as keyof typeof prev], close: e.target.value },
                          }))
                        }
                        className="w-28 text-sm"
                      />
                    </div>
                  )}
                  
                  {!hours.enabled && (
                    <span className="text-sm text-gray-400 ml-8 sm:ml-0">Fechado</span>
                  )}
                </div>
              ))}

              <Button onClick={handleSave} disabled={isSaving} className="gap-2 mt-4">
                <Save className="w-4 h-4" />
                {isSaving ? 'Salvando...' : 'Salvar Alterações'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Account Settings */}
        <TabsContent value="account">
          <div className="space-y-4 sm:space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base sm:text-lg">Dados da Conta</CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Gerencie suas informações pessoais
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="userName" className="text-xs sm:text-sm">Nome</Label>
                    <Input
                      id="userName"
                      defaultValue={user?.name || 'Admin'}
                      className="text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="userEmail" className="text-xs sm:text-sm">E-mail</Label>
                    <Input
                      id="userEmail"
                      type="email"
                      defaultValue={user?.email || 'admin@azzo.com'}
                      className="text-sm"
                    />
                  </div>
                </div>

                <Button onClick={handleSave} disabled={isSaving} className="gap-2">
                  <Save className="w-4 h-4" />
                  {isSaving ? 'Salvando...' : 'Salvar Alterações'}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                  <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-violet-600" />
                  Segurança
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Altere sua senha de acesso
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword" className="text-xs sm:text-sm">Senha Atual</Label>
                  <Input id="currentPassword" type="password" className="text-sm" />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="newPassword" className="text-xs sm:text-sm">Nova Senha</Label>
                    <Input id="newPassword" type="password" className="text-sm" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword" className="text-xs sm:text-sm">Confirmar Senha</Label>
                    <Input id="confirmPassword" type="password" className="text-sm" />
                  </div>
                </div>

                <Button variant="outline" className="gap-2">
                  <Shield className="w-4 h-4" />
                  Alterar Senha
                </Button>
              </CardContent>
            </Card>

            <Card className="border-red-200">
              <CardHeader>
                <CardTitle className="text-red-600 text-base sm:text-lg">Zona de Perigo</CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Ações irreversíveis para sua conta
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="destructive" size="sm">
                  Excluir Conta
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
}