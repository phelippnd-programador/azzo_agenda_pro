import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { ApuracaoCard } from '@/components/fiscal/ApuracaoCard';
import { ApuracaoImpostoList } from '@/components/fiscal/ApuracaoImpostoList';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { apuracaoStorage } from '@/lib/apuracao-storage';
import { formatCurrency } from '@/lib/tax-calculator';
import {
  ApuracaoMensal as ApuracaoMensalType,
  ApuracaoResumo,
  MESES_PT,
  STATUS_COLORS,
  STATUS_LABELS,
} from '@/types/apuracao';
import { RefreshCw, Calendar, TrendingUp, History, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

export default function ApuracaoMensal() {
  const [apuracaoAtual, setApuracaoAtual] = useState<ApuracaoMensalType | null>(null);
  const [historico, setHistorico] = useState<ApuracaoResumo[]>([]);
  const [anoSelecionado, setAnoSelecionado] = useState<number>(new Date().getFullYear());
  const [mesSelecionado, setMesSelecionado] = useState<number | null>(null);
  const [apuracaoSelecionada, setApuracaoSelecionada] = useState<ApuracaoMensalType | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Anos disponíveis para seleção
  const anosDisponiveis = [2024, 2025, 2026];

  // Carregar apuração do mês atual
  useEffect(() => {
    carregarApuracaoAtual();
    carregarHistorico();
  }, []);

  // Carregar apuração quando mudar o mês selecionado
  useEffect(() => {
    if (mesSelecionado !== null) {
      carregarApuracaoSelecionada(anoSelecionado, mesSelecionado);
    }
  }, [mesSelecionado, anoSelecionado]);

  const carregarApuracaoAtual = () => {
    setIsLoading(true);
    try {
      const apuracao = apuracaoStorage.getOrCalculateMesAtual();
      setApuracaoAtual(apuracao);
    } catch (error) {
      console.error('Erro ao carregar apuração:', error);
      toast.error('Erro ao carregar apuração do mês atual');
    } finally {
      setIsLoading(false);
    }
  };

  const carregarHistorico = () => {
    try {
      const hist = apuracaoStorage.getHistorico(12);
      setHistorico(hist);
    } catch (error) {
      console.error('Erro ao carregar histórico:', error);
    }
  };

  const carregarApuracaoSelecionada = (ano: number, mes: number) => {
    setIsLoading(true);
    try {
      const apuracao = apuracaoStorage.getOrCalculate(ano, mes);
      setApuracaoSelecionada(apuracao);
    } catch (error) {
      console.error('Erro ao carregar apuração:', error);
      toast.error('Erro ao carregar apuração do período');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRecalcular = () => {
    setIsLoading(true);
    try {
      const hoje = new Date();
      const apuracao = apuracaoStorage.recalcular(hoje.getFullYear(), hoje.getMonth() + 1);
      setApuracaoAtual(apuracao);
      carregarHistorico();
      toast.success('Apuração recalculada com sucesso!');
    } catch (error) {
      console.error('Erro ao recalcular:', error);
      toast.error('Erro ao recalcular apuração');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelecionarMes = (mes: number) => {
    setMesSelecionado(mes);
  };

  const handleVoltarMesAtual = () => {
    setMesSelecionado(null);
    setApuracaoSelecionada(null);
  };

  // Apuração a ser exibida (selecionada ou atual)
  const apuracaoExibida = mesSelecionado !== null ? apuracaoSelecionada : apuracaoAtual;

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Calculator className="h-7 w-7 text-violet-600" />
              Apuração Mensal de Impostos
            </h1>
            <p className="text-gray-600 mt-1">
              Acompanhe os impostos devidos e o total a pagar por período
            </p>
          </div>
          <div className="flex gap-2">
            {mesSelecionado !== null && (
              <Button variant="outline" onClick={handleVoltarMesAtual}>
                <Calendar className="h-4 w-4 mr-2" />
                Mês Atual
              </Button>
            )}
            <Button onClick={handleRecalcular} disabled={isLoading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Recalcular
            </Button>
          </div>
        </div>

        <Tabs defaultValue="atual" className="space-y-4">
          <TabsList>
            <TabsTrigger value="atual" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Mês Atual
            </TabsTrigger>
            <TabsTrigger value="historico" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              Histórico
            </TabsTrigger>
          </TabsList>

          {/* Tab: Mês Atual */}
          <TabsContent value="atual" className="space-y-6">
            {apuracaoExibida ? (
              <>
                {/* Card de Resumo */}
                <ApuracaoCard apuracao={apuracaoExibida} />

                {/* Lista de Impostos */}
                <ApuracaoImpostoList
                  impostos={apuracaoExibida.impostos}
                  showZeroValues={true}
                />

                {/* Informações Adicionais */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Informações da Apuração</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-500">Data de Abertura</p>
                        <p className="font-medium">
                          {new Date(apuracaoExibida.dataAbertura).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-500">Regime Tributário</p>
                        <p className="font-medium">
                          {apuracaoExibida.regimeTributario.replace('_', ' ')}
                        </p>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-500">Última Atualização</p>
                        <p className="font-medium">
                          {new Date(apuracaoExibida.updatedAt).toLocaleString('pt-BR')}
                        </p>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-500">Status</p>
                        <Badge
                          className={`${STATUS_COLORS[apuracaoExibida.status].bg} ${
                            STATUS_COLORS[apuracaoExibida.status].text
                          }`}
                        >
                          {STATUS_LABELS[apuracaoExibida.status]}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-500">Carregando apuração...</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Tab: Histórico */}
          <TabsContent value="historico" className="space-y-6">
            {/* Seletor de Ano */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Selecionar Período</CardTitle>
                  <Select
                    value={anoSelecionado.toString()}
                    onValueChange={(value) => setAnoSelecionado(parseInt(value))}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {anosDisponiveis.map((ano) => (
                        <SelectItem key={ano} value={ano.toString()}>
                          {ano}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mês</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Serviços</TableHead>
                      <TableHead className="text-right">Impostos</TableHead>
                      <TableHead className="text-right">Notas</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {historico
                      .filter((h) => h.ano === anoSelecionado)
                      .map((item) => (
                        <TableRow
                          key={`${item.ano}-${item.mes}`}
                          className={
                            mesSelecionado === item.mes && anoSelecionado === item.ano
                              ? 'bg-violet-50'
                              : ''
                          }
                        >
                          <TableCell className="font-medium">
                            {MESES_PT[item.mes]}
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={`${STATUS_COLORS[item.status].bg} ${
                                STATUS_COLORS[item.status].text
                              } ${STATUS_COLORS[item.status].border} border`}
                            >
                              {STATUS_LABELS[item.status]}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            {formatCurrency(item.valorTotalServicos)}
                          </TableCell>
                          <TableCell className="text-right font-medium text-red-600">
                            {formatCurrency(item.valorTotalImpostos)}
                          </TableCell>
                          <TableCell className="text-right">
                            {item.quantidadeDocumentos}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleSelecionarMes(item.mes)}
                            >
                              Ver Detalhes
                              <ChevronRight className="h-4 w-4 ml-1" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Resumo do Ano */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Resumo do Ano {anoSelecionado}</CardTitle>
              </CardHeader>
              <CardContent>
                {(() => {
                  const resumo = apuracaoStorage.getResumoAno(anoSelecionado);
                  return (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 bg-blue-50 rounded-lg text-center">
                        <p className="text-sm text-gray-600">Total de Serviços</p>
                        <p className="text-2xl font-bold text-blue-700">
                          {formatCurrency(resumo.totalServicos)}
                        </p>
                      </div>
                      <div className="p-4 bg-red-50 rounded-lg text-center">
                        <p className="text-sm text-gray-600">Total de Impostos</p>
                        <p className="text-2xl font-bold text-red-700">
                          {formatCurrency(resumo.totalImpostos)}
                        </p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-lg text-center">
                        <p className="text-sm text-gray-600">Total de Notas</p>
                        <p className="text-2xl font-bold text-green-700">
                          {resumo.totalDocumentos}
                        </p>
                      </div>
                    </div>
                  );
                })()}
              </CardContent>
            </Card>

            {/* Detalhes do Mês Selecionado */}
            {apuracaoSelecionada && mesSelecionado !== null && (
              <div className="space-y-6">
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-semibold">
                    Detalhes: {MESES_PT[mesSelecionado]} {anoSelecionado}
                  </h2>
                </div>
                <ApuracaoCard apuracao={apuracaoSelecionada} />
                <ApuracaoImpostoList
                  impostos={apuracaoSelecionada.impostos}
                  showZeroValues={true}
                />
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}

// Ícone Calculator que estava faltando
function Calculator(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <rect width="16" height="20" x="4" y="2" rx="2" />
      <line x1="8" x2="16" y1="6" y2="6" />
      <line x1="16" x2="16" y1="14" y2="18" />
      <path d="M16 10h.01" />
      <path d="M12 10h.01" />
      <path d="M8 10h.01" />
      <path d="M12 14h.01" />
      <path d="M8 14h.01" />
      <path d="M12 18h.01" />
      <path d="M8 18h.01" />
    </svg>
  );
}