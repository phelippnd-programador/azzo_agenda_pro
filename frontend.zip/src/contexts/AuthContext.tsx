import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { authApi, User, initializeDemoData } from '@/lib/api';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: {
    name: string;
    email: string;
    password: string;
    salonName: string;
    phone: string;
  }) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    initializeDemoData();

    const token = localStorage.getItem("token");
    if (token) {
      setUser({} as User);
    }

    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    await authApi.login(email, password);

    // Se tem token, considera autenticado
    const token = localStorage.getItem("token");
    if (token) {
      setUser({} as User); // usuário fake apenas para liberar acesso
    }
  };


  const register = async (data: {
    name: string;
    email: string;
    password: string;
    salonName: string;
    phone: string;
  }) => {
    const response = await authApi.register(data);
    setUser(response.user);
  };

  const logout = async () => {
    await authApi.logout();
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}