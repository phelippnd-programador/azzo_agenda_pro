import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Invoice } from '@/types/invoice';
import { FileText, User, Calendar, DollarSign, Hash } from 'lucide-react';

interface InvoiceViewerProps {
  invoice: Invoice;
}

const getStatusColor = (status: string) => {
  const colors = {
    ISSUED: 'bg-green-100 text-green-700 border-green-200',
    DRAFT: 'bg-amber-100 text-amber-700 border-amber-200',
    CANCELLED: 'bg-red-100 text-red-700 border-red-200',
  };
  return colors[status as keyof typeof colors];
};

const getStatusLabel = (status: string) => {
  const labels = {
    ISSUED: 'Emitida',
    DRAFT: 'Rascunho',
    CANCELLED: 'Cancelada',
  };
  return labels[status as keyof typeof labels];
};

export function InvoiceViewer({ invoice }: InvoiceViewerProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>
              {invoice.type === 'NFE' ? 'NF-e - Modelo 55' : 'NFC-e - Modelo 65'}
            </CardTitle>
            <Badge className={getStatusColor(invoice.status)}>
              {getStatusLabel(invoice.status)}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-gray-500">Número</p>
              <p className="font-medium">{invoice.number}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Série</p>
              <p className="font-medium">{invoice.series}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Data de Emissão</p>
              <p className="font-medium">{formatDate(invoice.issueDate)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Natureza da Operação</p>
              <p className="font-medium">{invoice.operationNature}</p>
            </div>
          </div>
          {invoice.accessKey && (
            <>
              <Separator />
              <div>
                <p className="text-sm text-gray-500 mb-1">Chave de Acesso</p>
                <p className="font-mono text-sm break-all">{invoice.accessKey}</p>
              </div>
            </>
          )}
          {invoice.authorizationProtocol && (
            <div>
              <p className="text-sm text-gray-500 mb-1">Protocolo de Autorização</p>
              <p className="font-mono text-sm">{invoice.authorizationProtocol}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Customer */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5 text-violet-600" />
            Dados do Tomador
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Nome/Razão Social</p>
              <p className="font-medium">{invoice.customer.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">{invoice.customer.type}</p>
              <p className="font-medium">{invoice.customer.document}</p>
            </div>
          </div>
          {(invoice.customer.email || invoice.customer.phone) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {invoice.customer.email && (
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="font-medium">{invoice.customer.email}</p>
                </div>
              )}
              {invoice.customer.phone && (
                <div>
                  <p className="text-sm text-gray-500">Telefone</p>
                  <p className="font-medium">{invoice.customer.phone}</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Items */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-violet-600" />
            Serviços Prestados
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {invoice.items.map((item, index) => (
              <div key={item.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1">
                    <p className="font-medium">{item.description}</p>
                    <p className="text-sm text-gray-500">
                      CFOP: {item.cfop} | CST: {item.cst}
                    </p>
                  </div>
                  <Badge variant="outline">Item {index + 1}</Badge>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Quantidade</p>
                    <p className="font-medium">{item.quantity}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Valor Unitário</p>
                    <p className="font-medium">{formatCurrency(item.unitPrice)}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Total</p>
                    <p className="font-medium">{formatCurrency(item.totalPrice)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tax Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-violet-600" />
            Tributos e Totais
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-gray-600 mb-1">ICMS</p>
              <p className="font-bold text-blue-700">{formatCurrency(invoice.taxBreakdown.icms)}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <p className="text-gray-600 mb-1">PIS</p>
              <p className="font-bold text-green-700">{formatCurrency(invoice.taxBreakdown.pis)}</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <p className="text-gray-600 mb-1">COFINS</p>
              <p className="font-bold text-purple-700">{formatCurrency(invoice.taxBreakdown.cofins)}</p>
            </div>
          </div>
          <Separator />
          <div className="bg-gradient-to-r from-violet-50 to-pink-50 p-4 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-lg font-medium">Valor Total da Nota:</span>
              <span className="text-3xl font-bold text-violet-700">
                {formatCurrency(invoice.totalValue)}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notes */}
      {invoice.notes && (
        <Card>
          <CardHeader>
            <CardTitle>Observações</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 whitespace-pre-wrap">{invoice.notes}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}