'use client';

import { useState, useEffect } from 'react';
import { TaxRegime, TaxRate } from '@/types/fiscal';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

export function TaxConfigForm() {
  const { toast } = useToast();
  const [regime, setRegime] = useState<TaxRegime>(TaxRegime.SIMPLES_NACIONAL);
  const [icmsRate, setIcmsRate] = useState<string>('');
  const [pisRate, setPisRate] = useState<string>('');
  const [cofinsRate, setCofinsRate] = useState<string>('');

  useEffect(() => {
    // Load saved configuration
    const saved = localStorage.getItem('taxConfig');
    if (saved) {
      const config = JSON.parse(saved);
      setRegime(config.regime);
      setIcmsRate(config.icmsRate.toString());
      setPisRate(config.pisRate.toString());
      setCofinsRate(config.cofinsRate.toString());
    } else {
      // Set default rates for Simples Nacional
      setIcmsRate('2.75');
      setPisRate('0.65');
      setCofinsRate('3.00');
    }
  }, []);

  const handleRegimeChange = (value: string) => {
    const newRegime = value as TaxRegime;
    setRegime(newRegime);

    // Set default rates based on regime
    if (newRegime === TaxRegime.SIMPLES_NACIONAL) {
      setIcmsRate('2.75');
      setPisRate('0.65');
      setCofinsRate('3.00');
    } else {
      setIcmsRate('18.00');
      setPisRate('1.65');
      setCofinsRate('7.60');
    }
  };

  const handleSave = () => {
    const config = {
      regime,
      icmsRate: parseFloat(icmsRate),
      pisRate: parseFloat(pisRate),
      cofinsRate: parseFloat(cofinsRate),
    };

    localStorage.setItem('taxConfig', JSON.stringify(config));

    toast({
      title: 'Configuração salva',
      description: 'As alíquotas de impostos foram atualizadas com sucesso.',
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Configuração de Impostos</CardTitle>
        <CardDescription>
          Configure as alíquotas de impostos para emissão de notas fiscais
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="regime">Regime Tributário</Label>
          <Select value={regime} onValueChange={handleRegimeChange}>
            <SelectTrigger id="regime">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={TaxRegime.SIMPLES_NACIONAL}>
                Simples Nacional
              </SelectItem>
              <SelectItem value={TaxRegime.LUCRO_PRESUMIDO}>
                Lucro Presumido
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label htmlFor="icms">Alíquota ICMS (%)</Label>
            <Input
              id="icms"
              type="number"
              step="0.01"
              min="0"
              max="100"
              value={icmsRate}
              onChange={(e) => setIcmsRate(e.target.value)}
              placeholder="2.75"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="pis">Alíquota PIS (%)</Label>
            <Input
              id="pis"
              type="number"
              step="0.01"
              min="0"
              max="100"
              value={pisRate}
              onChange={(e) => setPisRate(e.target.value)}
              placeholder="0.65"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cofins">Alíquota COFINS (%)</Label>
            <Input
              id="cofins"
              type="number"
              step="0.01"
              min="0"
              max="100"
              value={cofinsRate}
              onChange={(e) => setCofinsRate(e.target.value)}
              placeholder="3.00"
            />
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-semibold text-blue-900 mb-2">Informações sobre o regime selecionado:</h4>
          {regime === TaxRegime.SIMPLES_NACIONAL ? (
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Alíquotas típicas: ICMS 2-3%, PIS 0.65%, COFINS 3%</li>
              <li>• Cálculo simplificado sobre o faturamento</li>
              <li>• Indicado para pequenas empresas</li>
            </ul>
          ) : (
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Alíquotas típicas: ICMS 18%, PIS 1.65%, COFINS 7.6%</li>
              <li>• Cálculo sobre base de cálculo específica</li>
              <li>• Regime para empresas de maior porte</li>
            </ul>
          )}
        </div>

        <Button onClick={handleSave} className="w-full">
          Salvar Configuração
        </Button>
      </CardContent>
    </Card>
  );
}